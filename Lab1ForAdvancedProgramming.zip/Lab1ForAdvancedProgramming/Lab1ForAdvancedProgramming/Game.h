#pragma once

#include "stdafx.h"


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include "Achievement.cpp"
#include "Achievement.h"
#include "Game.cpp"
#include "Platform.h"

using namespace std;

class Game
{
private:

	string name;
	string publisher;
	string developer;
	Achievement achievements[5];
	int achievementCount = 0;
	

public:

	Game();
	~Game();

	string getName() { return name; }
	string getPublisher() { return publisher; }
	string getDeveloper() { return developer; }
	Achievement* getAchievement() { return Achievement; } //Type name is not allowed, Suggesting that I delete "return Achievement"
	Achievement* getAchievement(int index);
	void setName(string name) { this->name = name; }
	void setPublisher(string publisher) { this->publisher = publisher; }
	void setDeveloper(string developer) { this->developer = developer; }
	void setAchievement(string achievement) { this->Achievement = achievement; } // Class ''Game'' has no member "Achievement"
	void setAchievements(Achievement a[], int cnt);
	void addAchievement(Achievement a);


	string getName()
	{
		return name;
	}
	void setName(string n)
	{
		name = n;
	}
	string getAchievement(string a)
	{
		achievements[5];
	}


};

void Game::setAchievements(Achievement a[], int cnt)
{
	*achievements = a; // which operator does match?
	if (achievements != nullptr) { delete achievements; }
	Achievement = new Achievement[cnt]; // Expects which identifier? And no sutiable constructor exists to convert from "Achievement*" to "Achievement"

}

//Achievement = new Achievement[cnt];

for (int i = 0; i < cnt; i++) // Expects which declaration?
{
	achievement[i] = a[i];

}
achievementCount = cnt;
int achievementSize(int cnt);

void Game::addAchievement(Achievement a)
{
	
	if (achievementCount == achievementSize) //Operand types are not compatible
	{
		Achievement* tmp = new Achievement[achievementCount * 2];
		for (int i = 0; 1 < achievementCount; i++)
		{
			tmp[i] = achievements[i];
		}
		delete achievements;
		achievements[5] == tmp; //No operators match
		achievementSize == 2 * achievementCount; //Operand types are not compatible

	}
	achievements[achievementCount++] = a;
}

