#pragma once

#include "stdafx.h"


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include "Game.h"
#include "Platform.h"
#include "Achievement.h"


using namespace std;

class Achievement
{
private:
	string title;
	string description;
	int Score;

public:

	Achievement();
	Achievement(string title, string description);
	~Achievement();
	string getTitle() { return title; }
	string getDescription() { return description; }
	int getScore() { return Score; }
	void setTitle(string title) { this->title = title; }
	void setDescription(string description) { this->description = description; }
	void setScore(string score) { this->Score = Score; }


};

Achievement::Achievement()
{
	title = " ";
	description = " ";
	Score = 0;


}

Achievement::Achievement(string title, string description)
{
	this->title = title;
	this->description = description;
	this->Score = Score;


}


