#include "stdafx.h"


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include "Lab1ForAdvancedProgramming.cpp"

using namespace std;

class Platform
{
private:
	string name;
	string manufacterer;
	Game games[5];



public:

	string getName()
	{
		return name;
	}
	void setName(string n)
	{
		name = n;
	}
	string manufacterer(string m)
	{
		manufacterer = m;
	}
};

